<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Document sans titre</title>
</head>

<body>
    <form action="auth.php?a=1" method="post">
		<input type="email" placeholder="Email" name="email"/>
        <input type="password" placeholder="Password" name="password"/>
        <input type="submit"/>    
    </form>
<br><br>
    <form action="auth.php?a=2" method="post">
		<input type="text" placeholder="Full Name" name="name"/>
        <input type="text" placeholder="Username" name="username"/>
        <input type="email" placeholder="Email" name="email"/>
        <input type="password" placeholder="Password" name="password"/>
		 <input type="radio" name="gender" value="M" checked> Male<br>
        <input type="radio" name="gender" value="F"> Female<br>
        <input type="submit"/>    
    </form>


</body>
</html>