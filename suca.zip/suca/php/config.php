<?php

	$hostname ="localhost";
	$db_name ="suca";
	$db_user ="root";
	$db_password ="";
	
	$connect= mysqli_connect($hostname,$db_user,$db_password,$db_name);
	//mysqli_set_charset($connect, 'UTF-8');
	
	session_start();
	$_SESSION['id'] = null;
?>