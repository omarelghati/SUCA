<?php
function login($email,$password,$token,$connect)
{
  	 $result = mysqli_query($connect,"SELECT * FROM users WHERE email = '$email' AND password = '$password'") or die("Failed to query database".mysqli_error($connect));
  	 $row = mysqli_fetch_array($result);
     if($row['email'] == $email && $row['password'] == $password) {
        $_SESSION['id'] = $row['id'];
		$_SESSION['name'] = $row['name'];
        $_SESSION['username'] = $row['username'];
		$_SESSION['email'] = $row['email'];
		$_SESSION['photo'] = $row['photo'];
		$_SESSION['gender'] = $row['gender'];
		
		echo $row['photo'];
      }
      else{
	    ?>
	        <script>alert('E-mail /password incdorrect !');</script>
	    <?php 
	  }
}

function register($name,$username,$email,$password,$gender,$connect)
{
	$query = "SELECT email FROM users WHERE email='$email'";
  $result = mysqli_query($connect,$query);
  
  $count = mysqli_num_rows($result);
  if(!$count){
	$default_photo = addslashes(file_get_contents('img/avatar.jpeg'));
	mysqli_query($connect,"INSERT INTO users (`name`,`username`, `email`, `password`,`gender`,`photo`) VALUES ('$name','$username','$email','$password','$gender', '$default_photo')") or die(mysqli_error($connect));
	  /*{
	  ?>
	  <script>alert('successfully registered ');</script>
	  <?php
	}
	else
	{
	  ?>
	  <script>alert('error while registering you...');</script>
	  <?php
	}   */
  
  }else{
	  ?>
	  <script>alert('Sorry Email ID already taken ...');</script>
	  <?php
  }
}


function secure($input){
	$input = mysql_real_escape_string($input);
   $input = htmlspecialchars($input, ENT_IGNORE, 'utf-8');
   $input = strip_tags($input);
   $input = stripslashes($input);
   return $input;	
}

?>