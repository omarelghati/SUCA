<?php
	require("config.php");
	require("core.php");
	 
if(isset($_GET['a'])){
	
	$a= (int)$_GET['a'];
	if($a===1){
	$email = secure($_POST['email']);
     $password = md5($_POST['password']);
  	 $password = secure($password);
	 $token =1;
	login($email,$password,$token,$connect);
		echo "Wrong 2";	
	}elseif($a===2){
	$name = secure($_POST['name']);
	$gender = secure($_POST['gender']);
	$username = secure($_POST['username']);
	$email= secure($_POST['email']);
	$password = md5($_POST['password']);
	register($name,$username,$email,$password,$gender,$connect);	
}}else{
echo "Wrong"	;}

?>